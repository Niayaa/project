var Product     = require('../models/product');
var User        = require('../models/user');
var mongoose    = require('mongoose');
mongoose.connect('mongodb://localhost/shoppingApp');

var products = [
    new Product({
        imagePath   : 'https://c1-zingpopculture.eb-cdn.com.au/merchandising/images/packshots/500e85c2331549e2b29db323750299dd_Original.png',
        title       : 'Ash wand with unicorn tail hair core',
        description : 'Ash wand made with unicorn tail hair core cling to its one true master and ought not to be passed on or gifted from the original owner, because it will lose power and skill.',
        price       : 69.99
    }),
    new Product({
        imagePath   : 'https://www.thinkgeek.com/images/products/zoom/jujm_harrys_wand.jpg',
        title       : 'Elder Wand with White River Monster spine core',
        description : 'Elder is the rarest wand wood of all, and reputed to be deeply unlucky, elder wands are trickier to master than any other',
        price       : 69.99
    }),
    new Product({
        imagePath   : 'https://pm1.narvii.com/6506/cb65ee4a637862f2475035ad17dbd84d321509b6_hq.jpg',
        title       : 'Fir wood wand with Phoneix feather core',
        description : 'This wands made by Fir wood with a Phoenix feather core 11 3/4" and Slightly Springy flexibility',
        price       : 89.99
    }),
    new Product({
        imagePath   : 'https://pm1.narvii.com/6506/c464ab22ecb450fbb6fea0aab93986aa74e2fa00_hq.jpg',
        title       : 'Pear wand with Basilisk horn core',
        description : 'Possessors of pear wands are, in the experience of the learned wandmaker Garrick Ollivander, usually popular and well-respected and he never knew of single instance where a pear wand has been discovered in the possession of a Dark witch or wizard. ',
        price       : 79.99
    }),
    new Product({
        imagePath   : 'https://pm1.narvii.com/6506/4479ce241cb80b41bc9ce7bed93b3d6058243d69_hq.jpg',
        title       : 'Yew wand with Dragon heartstring core',
        description : 'Yew wands are among the rarer kinds, and their ideal matches are likewise unusual, and occasionally notorious. ',
        price       : 79.99
    }),
    new Product({
        imagePath   : 'https://i.pinimg.com/564x/82/8d/98/828d98d804ebfc32d46612ac25bc94b2.jpg',
        title       : 'Chestnut wand with Rougarou hair core',
        description : 'Chestnut wands prefer witches and wizards who are skilled tamers of magical beasts, those who possess great gifts in Herbology, and those who are natural fliers. But be carefully to use it, Rumoured to have an affinity for Dark magic, although suitable for use by non-Dark wizards and witches as well ',
        price       : 139.99
    }),
    new Product({
        imagePath   : 'http://c-7npsfqifvt34x24wjhofuufx2ex78jljbx2eopdppljfx2eofu.g00.wikia.com/g00/3_c-7ibsszqpuufs.x78jljb.dpn_/c-7NPSFQIFVT34x24iuuqtx3ax2fx2fwjhofuuf.x78jljb.opdppljf.ofux2fibsszqpuufsx2fjnbhftx2fex2fe6x2fIpsbdf_Tmvhipso_x78boe.qohx2fsfwjtjpox2fmbuftux2ftdbmf-up-x78jeui-epx78ox2f2111x3fdcx3d31272239163762x26j21d.nbslx3djnbhf_$/$/$/$/$/$/$/$/$/$',
        title       : 'Cedar wand with Dragon heartstring core',
        description : 'The Cedar wand finds its perfect home where there is perspicacity and perception. ',
        price       : 89.99
    }),
    new Product({
        imagePath   : 'https://i.pinimg.com/originals/19/c0/d2/19c0d281111329f989ea65da7d1a534b.jpg',
        title       : 'Enbony wand with Veela hair core',
        description : 'Ebony wands have an impressive appearance and reputation, being highly suited to all manner of combative magic, and to Transfiguration. Ebony is happiest in the hand of those with the courage to be themselves. ',
        price       : 79.99
    }),
    new Product({
        imagePath   : 'https://i.pinimg.com/564x/5e/8f/01/5e8f0129516ba0445e7fb336287041cb.jpg',
        title       : 'Larch wand with unicorn tail hair core',
        description : 'Larch wands have a reputation for instilling confidence and courage in the user. The celebrated wandmaker Garrick Ollivander found that larch always created wands of hidden talents and unexpected effects, which likewise describes the master who deserves it.',
        price       : 99.99
    }),
    new Product({
        imagePath   : 'https://i.pinimg.com/564x/ff/8f/7b/ff8f7b93075e4a037bb5cf235ab9b442.jpg',
        title       : 'Poplar wand with unicorn tail hair core',
        description : 'Poplar wands rely upon, of consistency, strength and uniform power, always happiest when working with a witch or wizard of clear moral vision. The existence of these wands and its owners was cited as evidence against a myth that poplar wands never chose politicians.',
        price       : 139.99
    }),

];

Product.remove({}, function(err){ //remove existing cat documents
    console.log("remove success");
  if(err) {
    console.log('ERROR: Remove failed')
    return
  }
  //ALL CAT DOCUMENTS REMOVED
});

for (var i = 0; i < products.length; i++){
    products[i].save(function(err, result) {
        if (i === products.length - 1){
            exit();
        }
    });
}

var newUser = new User({
    username    : 'admin@admin.com',
    password    : 'admin',
    fullname    : 'Cuneyt Celebican',
    admin       : true
});

var newUser = new User({
    username    : 'aki@gmail.com',
    password    : 'aki',
    fullname    : 'aki',
    admin       : true
});
User.createUser(newUser, function(err, user){
    if(err) throw err;
    console.log(user);
});


function exit() {
    mongoose.disconnect();
}
