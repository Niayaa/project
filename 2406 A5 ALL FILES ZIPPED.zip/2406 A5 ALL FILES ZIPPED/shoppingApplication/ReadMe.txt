Name: Liyongshi Chen  Student #101022029
      Jielu Yin       Student #101025025

Version: node.js v8.9.4
         macOS Sierra version: 10.12.6

Install: npm Install

Launch: node populate-for-startup.js then npm start 

Testing: 1.Please visit http://localhost:3000/
	2.Please enter “aki@gmail.com” as username at first. 
	3.Please enter your password “aki” then.
	4.Choose all items you want to buy and add them into shopping bag.
	5.If you change your mind, you also can remove them from the bag.
	6.If you are ready to pay. You just need to click the checkout button.
	7.After clicking “checkout”button, the PayPal website will be open.
	8.Then please follow the PayPal instructions, finish paying for your items.