var express                 = require('express');
var router                  = express.Router();
var Cart                    = require('../models/cart');
var Order                   = require('../models/order');
var paypal                  = require('paypal-rest-sdk');


// GET checkout page
router.get('/', ensureAuthenticated, function(req, res, next){
    console.log(`ROUTE: GET CHECKOUT PAGE`)
    var cart = new Cart(req.session.cart)
    var totalPrice = cart.totalPrice
    var finalPrice = totalPrice.toFixed(2);
    res.render('checkout', {title: 'Checkout Page', items: cart.generateArray(), totalPrice: finalPrice, bodyClass: 'registration', containerWrapper: 'container', userFirstName: req.user.fullname});
})

// POST checkout-process
router.post('/checkout-process', function(req, res){
   console.log(`ROUTE: POST CHECKOUT-PROGRESS`)
    var cart = new Cart(req.session.cart);
    var totalPrice = cart.totalPrice;
    //FOR NOW

       //either of these two could work
       //res.render('checkoutSuccess', {title: 'Successful', containerWrapper: 'container', userFirstName: req.user.fullname}
       var create_payment_json = {
           "intent": "sale",
           "payer": {
               "payment_method": "paypal"
           },
           "redirect_urls": {
               "return_url": "http://localhost:3000/checkout/checkout-success",
               "cancel_url": "http://localhost:3000/checkout/checkout-cancel"
           },
           "transactions": [{
               "item_list": {
                   "items": [{
                       "name": "item",
                       "sku": "item",
                       "price":totalPrice.toFixed(2),
                       "currency": "CAD",
                       "quantity": 1
                   }]
               },
               "amount": {
                   "currency": "CAD",
                   "total": totalPrice.toFixed(2)
               },
               "description": "This is the payment description."
           }]
       };


        paypal.payment.create(create_payment_json, function (error, payment) {
            if (error) {
                throw error;
            } else {
                console.log("Create Payment Response");
                console.log(payment);
                if(payment.payer.payment_method === 'paypal')
                {
                  req.session.paymentId = payment.id;
                  var redirect;
                  for(var i=0; i<payment.links.length; i++)
                  {
                    var link = payment.links[i];
                    if(link.method === 'REDIRECT')
                    {
                      redirect = link.href;
                    }
                  }
                  res.redirect(redirect);
                }
            }
        });
      // res.redirect(302, '/checkout/checkout-success'
});
// GET checkout-success
router.get('/checkout-success', ensureAuthenticated, function(req, res){
    console.log(`ROUTE: GET CHECKOUT-SUCCESS`)
    var cart = new Cart(req.session.cart);
    var totalPrice = cart.totalPrice;
    var paymentid = req.query.paymentId;
    var payerId =  req.query.PayerID;
    var details = {
       "payer_id": payerId,
       "transactions": [{
           "amount": {
               "currency": "CAD",
               "total": totalPrice.toFixed(2)
           },
           "description": "future of sauces"
       }]
   };
   paypal.payment.execute(paymentid, details, function(error, payment) {
       if (error) {
           console.log("Error :", error);
       } else {
           console.log(payment);
           console.log("Result : ",JSON.stringify(payment));
           var newOrder = new Order({
               orderID             : paymentid,
               username            : req.user.username,
               address             : '1 Maire-Victorin, Toronto Ontario M5A 1E1 Canada',
               orderDate           : payment.create_time,
               shipping            : true
             });
           newOrder.save();
       }
   })

    //remove items in cart
    req.session.cart.items = {};
    req.session.cart.totalQty = 0;
    req.session.cart.totalPrice = 0;
    res.render('checkoutSuccess', {title: 'Successful', containerWrapper: 'container', userFirstName: req.user.fullname})
});

// PAYMENT CANCEL
router.get('/checkout-cancel', ensureAuthenticated, function(req, res){
    console.log(`ROUTE: GET CHECKOUT-CANCEL`)
    res.render('checkoutCancel', {title: 'Successful', containerWrapper: 'container', userFirstName: req.user.fullname});
});

function ensureAuthenticated(req, res, next){
    if(req.isAuthenticated()){
        return next();
    }
    else{
        console.log(`ERROR: USER IS NOT AUTHENTICATED`)
        req.flash('error_msg', 'You are not logged in');
        res.redirect('/');
    }
}

module.exports = router;
